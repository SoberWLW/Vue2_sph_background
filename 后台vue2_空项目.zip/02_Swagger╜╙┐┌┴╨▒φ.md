# Swagger接口列表
## 接口文档
    商品、分类、品牌：http://39.99.186.36:8216/swagger-ui.html
    网站首页Banner列表: http://39.99.186.36:8210/swagger-ui.html
    活动与优惠券：http://39.99.186.36:8200/swagger-ui.html
    购物车：http://39.99.186.36:8201/swagger-ui.html
    评论：http://39.99.186.36:8209/swagger-ui.html
    sku详情：http://39.99.186.36:8202/swagger-ui.html
    搜索：http://39.99.186.36:8203/swagger-ui.html
    订单：http://39.99.186.36:8204/swagger-ui.html
    支付：http://39.99.186.36:8205/swagger-ui.html
    用户：http://39.99.186.36:8208/swagger-ui.html
    权限: http://39.99.186.36:8170/swagger-ui.html

## 线上项目
    后台管理: http://47.93.148.192:7070/
    前台PC: http://gmall.atguigu.cn/
    库存地址：http://39.99.186.36:9000